# Example

This is an example to build the blinky project. It assumes nRF5 SDK is in `../../toolchains/nRF5/nRF5_SDK`. If not, modify `CMakeLists.txt` 