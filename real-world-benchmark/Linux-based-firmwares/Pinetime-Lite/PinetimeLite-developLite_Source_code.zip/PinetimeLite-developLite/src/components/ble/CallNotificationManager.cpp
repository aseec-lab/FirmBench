#include "CallNotificationManager.h"
#include <cstring>
#include <algorithm>

using namespace Pinetime::Controllers;

