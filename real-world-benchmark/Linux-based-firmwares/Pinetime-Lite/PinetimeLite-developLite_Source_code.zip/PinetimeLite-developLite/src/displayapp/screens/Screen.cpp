#include "Screen.h"
using namespace Pinetime::Applications::Screens;