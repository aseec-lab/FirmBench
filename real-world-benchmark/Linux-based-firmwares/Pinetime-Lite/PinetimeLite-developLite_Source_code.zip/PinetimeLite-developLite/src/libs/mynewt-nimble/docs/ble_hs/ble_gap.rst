NimBLE Host GAP Reference
-------------------------

Introduction
~~~~~~~~~~~~

The Generic Access Profile (GAP) is responsible for all connecting, advertising, scanning, and connection updating operations.

API
~~~~~~

.. doxygengroup:: bt_host_gap
    :content-only:
    :members:
