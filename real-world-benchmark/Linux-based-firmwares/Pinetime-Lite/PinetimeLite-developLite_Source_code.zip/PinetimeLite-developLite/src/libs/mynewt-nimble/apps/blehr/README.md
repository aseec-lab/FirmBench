# BLE Heart Rate peripheral app.

The source files are located in the src/ directory.

pkg.yml contains the base definition of the app.

syscfg.yml contains setting definitions and overrides.


