Docker images and build script for building the project using Docker.
See [this page for more info](../doc/buildWithDocker.md).