Steps to add the plugin:

- Copy the dither16bit.scm file to the script directory of GIMP (On Linux: /home/user/.gimp-*/scripts)
- Copy the the 4 Grayscale palette files (.gpl) file to the palette directory of GIMP (On Linux: /home/user/.gimp-/palettes)

To make dithering open GIMP and click Image->Mode->Dither to RGB565 and save the new image.